from django.shortcuts import render
from .models import Product


# Create your views here.

def index(request):
    
    best_sell = "bsell content-icon people fa fa-users"
    offer = "offer fa fa-gift"
    limited = "limited fa fa-eye"

    product_1 = Product()
    product_1.img = "ShopRoll Open_10170111.jpg"
    product_1.name = "A. ShopRoll "
    product_1.price = 59.99
    product_1.icon = offer

    product_2 = Product()
    product_2.img = "Gear Bag XL 1_07040155.jpg"
    product_2.name = "Medium and X-Large Gear Bags "
    product_2.price = 77.99
    product_2.icon = best_sell

    product_3 = Product()
    product_3.img = "travel-backpack-wooden-bench-forest-summer-active-hiking-trekking-tools-92633051.jpg"
    product_3.name = "travel-backpack-wooden"
    product_3.price = 65.99
    product_3.icon = best_sell

    product_4 = Product()
    product_4.img = "image3_10160328.jpg"
    product_4.name = "K. Wool Camp Blanket (Large, 3 Varieties)"
    product_4.price = 87.99
    product_4.icon = limited

    products = [product_1, product_2, product_3, product_4]


    return render(request,'index.html', {'products':products})