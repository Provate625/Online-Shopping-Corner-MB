from django.db import models

# Create your models here.

class Product:
    id: int
    img:str
    price: float
    name:str
    icon:str 