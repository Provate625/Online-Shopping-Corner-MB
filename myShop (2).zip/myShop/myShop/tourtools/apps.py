from django.apps import AppConfig


class TourtoolsConfig(AppConfig):
    name = 'tourtools'
